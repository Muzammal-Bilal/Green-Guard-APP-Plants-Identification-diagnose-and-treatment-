// ignore: file_names
import 'package:flutter/material.dart';

class Askexpert extends StatefulWidget {
  const Askexpert({super.key});

  @override
  State<Askexpert> createState() => _AskexpertState();
}

class _AskexpertState extends State<Askexpert> {
  // List of Plant Experts
  final List<PlantExpert> _experts = [
    PlantExpert(
      name: 'Dr. Green Thumb',
      contactNumber: '+123456789',
      specialization: 'Succulents',

      imageUrl:
          'https://tse2.mm.bing.net/th?id=OIP.GaJG5jKUbm9RTdDB_bGKqgHaE8&pid=Api&P=0&h=220', // Replace with actual image URL
    ),
    PlantExpert(
      name: 'Herb Herbson',
      contactNumber: '+321456789',
      specialization: 'Tropical Plants',
      imageUrl:
          'https://tse2.mm.bing.net/th?id=OIP.-PsrmnreQ5odzUonVfmf4AHaFc&pid=Api&P=0&h=220', // Replace with actual image URL
    ),
    PlantExpert(
      name: 'Flora Foster',
      contactNumber: '+123456789',
      specialization: 'Herbs & Spices',
      imageUrl:
          'https://thumbs.dreamstime.com/b/studying-different-compositions-plants-young-scientist-working-plant-samples-lab-264187207.jpg', // Replace with actual image URL
    ),
    PlantExpert(
      name: 'Leafy Lane',
      contactNumber: '+231456789',
      specialization: 'Indoor Plants',
      imageUrl:
          'https://st3.depositphotos.com/9881890/14049/i/450/depositphotos_140490314-stock-photo-female-scientist-with-green-plant.jpg', // Replace with actual image URL
    ),
  ];

  void _bookSlot(PlantExpert expert) {
    // Handle booking logic here
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Booking Confirmed'),
        content: Text('You have booked a slot with ${expert.name}.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ask Expert'),
        backgroundColor: const Color(0xF0B2F11D),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: _experts.length,
        itemBuilder: (context, index) {
          final expert = _experts[index];
          return Card(
            elevation: 4.0,
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  // Image of the Expert
                  CircleAvatar(
                    radius: 40.0,
                    backgroundImage: NetworkImage(expert.imageUrl),
                  ),
                  const SizedBox(width: 16.0),
                  // Expert Details
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          expert.name,
                          style: const TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8.0),
                        Text(
                          'Specialization: ${expert.specialization}',
                          style: const TextStyle(
                            fontSize: 16.0,
                            color: Colors.green,
                          ),
                        ),
                        const SizedBox(height: 8.0),
                        Text(
                          'Contact: ${expert.contactNumber}',
                          style: const TextStyle(
                            fontSize: 16.0,
                          ),
                        ),
                        const SizedBox(height: 8.0),
                        Align(
                          alignment: Alignment.centerRight,
                          child: ElevatedButton(
                            onPressed: () => _bookSlot(expert),
                            child: const Text('Book Slot'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class PlantExpert {
  final String name;
  final String contactNumber;
  final String specialization;
  final String imageUrl; // Added image URL

  PlantExpert({
    required this.name,
    required this.contactNumber,
    required this.specialization,
    required this.imageUrl, // Include image URL in the constructor
  });
}
