import 'package:flutter/material.dart';
import 'package:flutter_application_1/Camra.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          // Background image from assets
          Image.asset(
            'bg.jpg', // Path to your image asset
            fit: BoxFit.cover,
          ),
          // Content on top of the background image
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    // Open camera for Identify
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Camra()),
                    );
                  },
                  child: Container(
                    height: 100,
                    width: 300,
                    decoration: const BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(255, 95, 162, 216),
                          blurRadius: 3,
                          spreadRadius: 4,
                        )
                      ],
                      color: Color.fromARGB(255, 236, 92, 92),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    padding: const EdgeInsets.all(20),
                    child: const Center(
                      child: Text('Identify',
                          style:
                              TextStyle(color: Color.fromARGB(255, 8, 8, 8))),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    // Open camera for Diagnose
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Camra()),
                    );
                  },
                  child: Container(
                    height: 100,
                    width: 300,
                    decoration: const BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(255, 95, 162, 216),
                          blurRadius: 3,
                          spreadRadius: 4,
                        )
                      ],
                      color: Colors.greenAccent,
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    padding: const EdgeInsets.all(20),
                    child: const Center(
                      child: Text('Diagnose',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ),
                // Uncomment this section if needed
                // const SizedBox(height: 20),
                // GestureDetector(
                //   onTap: () {
                //     // Open camera for Treatment
                //     Navigator.push(
                //       context,
                //       MaterialPageRoute(builder: (context) => const Camra()),
                //     );
                //   },
                //   child: Container(
                //     color: Colors.blue,
                //     padding: const EdgeInsets.all(20),
                //     child: const Text('3rd: Treatment',
                //         style: TextStyle(color: Colors.white)),
                //   ),
                // ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
