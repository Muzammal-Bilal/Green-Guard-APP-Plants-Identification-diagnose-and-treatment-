// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';
import 'dart:math'; // Import dart:math for Random

class Camra extends StatefulWidget {
  const Camra({super.key});

  @override
  State<Camra> createState() => _CamraState();
}

class _CamraState extends State<Camra> {
  final List<String> name = ["Apple", "Apple", "Tamato", "Tomato", "Tomato"];
  final List<String> daignose = [
    "Apple_Scab",
    "Apple_Healthy",
    "Tamato_Healthy",
    "Tomato_Mosaic Virus",
    "Tomato : Bacterial Spot"
  ];
  final List<String> about = [
    "Apple scab is the most common disease of apple and crabapple trees in Minnesota.Scab is caused by a fungus that infects both leaves and fruit.Scabby fruit are often unfit for eating.Infected leaves have olive green to brown spots.Leaves with many leaf spots turn yellow and fall off early.Leaf loss weakens the tree when it occurs many years in a row.Planting disease resistantvarieties is the best way to manage scab.",
    "As with most fruit, apples produce best when grown in full sun, which means six or more hours of direct summer Sun daily.The best exposure for apples is a north side of a house, tree line, or rise rather than the south.Apple trees need well-drained soil, but should be able to retain some moisture.",
    "Fertilize one week before as well as on the day of planting. They especially love phosphorous, which promotes the formation of blossoms and the fruits or vegetables that grow from them. Avoid high nitrogen when your tomato plants have blossoms as it promotes vine growth rather than fruit growth.Don't Crowd Tomato Seedlings.Provide Lots of Light.Preheat the Garden Soil.Bury the Stems.Mulch Tomatoes After the Soil Has Warmed.Remove the Bottom Leaves.Pinch and Prune for More Tomatoes.Water Regularly.",
    "Tomato mosaic virus (ToMV) and  Tobacco mosaic virus (TMV) are hard to distinguish.Tomato mosaic virus (ToMV) can cause yellowing and stunting of tomato plants resulting in loss of stand and reduced yield.ToMV may cause uneven ripening of fruit, further reducing yield.Tobacco mosaic virus (TMV) was once thought to be more common on tomato. TMV is usually more of a tobacco pathogen than a tomato pathogen.Mottled light and dark green on leaves.Young tomato leaf that is mottled light and dark green, stunted growth, curled and malformed leaves.Tobacco Mosaic virus symptoms on a tomato seedlingIf plants are infected early, they may appear yellow and stunted overall.Leaves may be curled, malformed, or reduced in size.",
    "Bacterial spot of tomato is a potentially devastating disease that, in severe cases, can lead to unmarketable fruit and even plant death.  Bacterial spot can occur wherever tomatoes are grown, but is found most frequently in warm, wet climates, as well as in greenhouses.  The disease is often an issue in Wisconsin.Bacterial spot can affect all above ground parts of a tomato plant, including the leaves, stems, and fruit.  Bacterial spot appears on leaves as small (less than ? inch), sometimes water-soaked (i.e., wet-looking) circular areas.  Spots may initially be yellow-green, but darken to brownish-red as they age.  When the disease is severe, extensive leaf yellowing and leaf loss can also occur.  On green fruit, spots are typically small, raised and blister-like, and may have a yellowish halo.  As fruit mature, the spots enlarge (reaching a maximum size of ¼ inch) and turn brown, scabby and rough.  Mature spots may be raised, or sunken with raised edges."
  ];
  final List<String> possible_step = [
    "Choose resistant varieties when possible.Rake under trees and destroy infected leaves to reduce the number of fungal spores available to start the disease cycle over again next spring.Water in the evening or early morning hours (avoid overhead irrigation) to give the leaves time to dry out before infection can occur.Spread a 3- to 6-inch layer of compost under trees, keepin it away from the trunk, to cover soil and prevent splash dispersal of the fungal spores.For best control, spray liquid copper soap early, two weeks before symptoms normally appear. Alternatively, begin applications when disease first appears, and repeat at 7 to 10 day intervals up to blossom drop.",
    "N/A",
    "N/A",
    "Use certified disease-free seed or treat your own seed.Soak seeds in a 10% solution of trisodium phosphate (Na3PO4) for at least 15 minutes.Or heat dry seeds to 158 °F and hold them at that temperature for two to four days.Purchase transplants only from reputable sources. Ask about the sanitation procedures they use to prevent disease.Inspect transplants prior to purchase. Choose only transplants showing no clear symptoms.Avoid planting in fields where tomato root debris is present, as the virus can survive long-term in roots.Wash hands with soap and water before and during the handling of plants to reduce potential spread between plants.",
    "Plant pathogen-free seed or transplants to prevent the introduction of bacterial spot pathogens on contaminated seed or seedlings.  If a clean seed source is not available or you suspect that your seed is contaminated, soak seeds in water at 122°F for 25 min. to kill the pathogens.  To keep leaves dry and to prevent the spread of the pathogens, avoid overhead watering (e.g., with a wand or sprinkler) of established plants and instead use a drip-tape or soaker-hose.  Also to prevent spread, DO NOT handle plants when they are wet (e.g., from dew) and routinely sterilize tools with either 10% bleach solution or (better) 70% alcohol (e.g., rubbing alcohol).  Where bacterial spot has been a recurring problem, consider using preventative applications of copper-based products registered for use on tomato, especially during warm, wet periods.  Keep in mind however, that if used excessively or for prolonged periods, copper may no longer control the disease.  Be sure to read and follow all label instructions of the product that you select to ensure that you use it in the safest and most effective manner possible."
  ];

  final ImagePicker _picker = ImagePicker();
  Uint8List? _imageBytes;
  bool _imagePicked = false;
  late int randomIndex; // Declare a variable to hold the random index

  @override
  void initState() {
    super.initState();
    final Random random = Random();
    randomIndex = random.nextInt(5); // Generate a random index between 0 and 4
  }

  Future<void> _pickImage(ImageSource source) async {
    final XFile? image = await _picker.pickImage(source: source);
    if (image != null) {
      final Uint8List imageBytes = await image.readAsBytes();
      setState(() {
        _imageBytes = imageBytes;
        _imagePicked = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final double screenWidth = size.width;
    final double screenHeight = size.height;

    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Camera Screen')),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_imageBytes != null)
                SizedBox(
                  width: screenWidth, // Set the width to the full screen width
                  child: Image.memory(
                    _imageBytes!,
                    height: screenHeight * 0.3, // Adjust the height as needed
                    fit: BoxFit
                        .cover, // Ensures the image covers the entire width
                  ),
                )
              else
                const Text(
                  'No image selected.',
                  style: TextStyle(color: Colors.redAccent),
                ),
              const SizedBox(height: 20),
              if (_imagePicked)
                Container(
                  decoration: const BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 95, 162, 216),
                        blurRadius: 3,
                        spreadRadius: 4,
                      )
                    ],
                    color: Color.fromRGBO(203, 213, 225, 1),
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  width: screenWidth * 0.9, // Adjust width to avoid overflow
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text(
                            'Plant Name:',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Flexible(
                            child: Text(
                              name[randomIndex], // Use the random index
                              style: const TextStyle(),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Text(
                            'Plant Diagnose:',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Flexible(
                            child: Text(
                              daignose[randomIndex], // Use the random index
                              style: const TextStyle(),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'About:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        about[randomIndex], // Use the random index
                        style: const TextStyle(),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Possible Steps:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        possible_step[randomIndex], // Use the random index
                        style: const TextStyle(),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Center(
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          width: screenWidth *
                              0.8, // Adjust width to fit the content
                          decoration: const BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(255, 109, 114, 117),
                                blurRadius: 3,
                                spreadRadius: 4,
                              )
                            ],
                            color: Color.fromARGB(255, 138, 132, 132),
                            borderRadius: BorderRadius.all(
                              Radius.circular(20),
                            ),
                          ),
                          child: const Column(
                            children: [
                              ListTile(
                                leading: Icon(
                                  Icons.thermostat,
                                  color: Colors.red,
                                ),
                                title: Text(
                                  'Temperature',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 45, 219, 22),
                                  ),
                                ),
                                subtitle: Text(
                                  '18C - 22C',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 53, 42, 42),
                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(
                                  Icons.sunny,
                                  color: Colors.red,
                                ),
                                title: Text(
                                  'Sunlight',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 45, 219, 22),
                                  ),
                                ),
                                subtitle: Text(
                                  'Full Sun',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 53, 42, 42),
                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(
                                  Icons.water_drop_outlined,
                                  color: Colors.red,
                                ),
                                title: Text(
                                  'Water',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 45, 219, 22),
                                  ),
                                ),
                                subtitle: Text(
                                  'Every 4-7 days',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 53, 42, 42),
                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(
                                  Icons.agriculture,
                                  color: Colors.red,
                                ),
                                title: Text(
                                  'Reporting',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 45, 219, 22),
                                  ),
                                ),
                                subtitle: Text(
                                  'Every 4 to 5 months',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 53, 42, 42),
                                  ),
                                ),
                              ),
                              ListTile(
                                leading: Icon(
                                  Icons.pest_control,
                                  color: Colors.red,
                                ),
                                title: Text(
                                  'Fertilizing',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 45, 219, 22),
                                  ),
                                ),
                                subtitle: Text(
                                  'Every 4 to 6 Weeks',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 53, 42, 42),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              else
                const Text(
                  'No diagnosis available.',
                  style: TextStyle(color: Colors.redAccent),
                ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => _pickImage(ImageSource.camera),
                child: const Text('Pick Image from Camera'),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () => _pickImage(ImageSource.gallery),
                child: const Text('Pick Image from Gallery'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(const MaterialApp(
    home: Camra(),
  ));
}
